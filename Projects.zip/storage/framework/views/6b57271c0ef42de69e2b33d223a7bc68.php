<?php if(in_array(app()->getLocale(), ['en', 'tr'], true)): ?>
<!-- LTR -->
<html lang="en" dir="ltr" data-bs-theme="light">
<?php elseif(app()->getLocale() == 'ar'): ?>
<!-- RTL -->
<html lang="ar" dir="rtl" data-bs-theme="light">
<?php endif; ?><?php /**PATH C:\xampp\htdocs\Project\Projects\resources\views/Projects/Sass/dir.blade.php ENDPATH**/ ?>