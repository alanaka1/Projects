

<?php $__env->startSection('title', 'Users Trash'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="page-heading d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3">

    <div>
        <h1>Users Trash</h1>
        <p>Manage deleted users.</p>
    </div>

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item"><a href="<?php echo e(route('users.index')); ?>">Users</a></li>
            <li class="breadcrumb-item active">Trash</li>
        </ol>
    </nav>

</div>


<section class="dashboard-card mb-4">

    <div class="card-header-custom flex-wrap gap-3">

        <div>
            <h5>Deleted Users</h5>
            <small>Manage users in the trash</small>
        </div>

        <a href="<?php echo e(route('users.index')); ?>" class="btn btn-primary btn-sm"><i class="fa-solid fa-arrow-left me-1"></i>Back to Users</a>

    </div>


    <div class="custom-datatable p-3">

        <!-- Controls -->
        <div class="custom-table-toolbar mb-3">
            <div class="custom-table-length">
                <label for="usersTrashLength">Show</label>

                <select id="usersTrashLength" class="form-select form-select-sm">
                    <?php echo $__env->make('Projects.Dashboard.include.ordersLength', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </select>

                <span>entries</span>
            </div>


            <div class="custom-table-search">
                <div class="input-group input-group-sm">
                    <span class="input-group-text"><i class="fa-solid fa-magnifying-glass"></i></span>
                    <input type="search" id="usersTrashSearch" class="form-control" placeholder="Search deleted users...">
                </div>
            </div>

        </div>


        <!-- Table -->
        <div class="table-responsive">
            <table id="usersTrashTable" class="table align-middle table-hover w-100 custom-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Surname</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Deleted At</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>

                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <tr>
                            <td><?php echo e($user->id); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->surname); ?></td>
                            <td><?php echo e($user->username); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($user->deleted_at); ?></td>
                            <td>
                                <div class="d-flex align-items-center gap-1 flex-nowrap">
                                    
                                    <form action="<?php echo e(route('users.restore', $user->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('هل أنت متأكد من استرجاع هذا المستخدم؟');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('POST'); ?>

                                        <button type="submit" class="btn btn-outline-success btn-sm table-action-btn" title="Restore"><i class="fa-solid fa-trash-arrow-up"></i></button>
                                    </form>

                                    
                                    <form action="<?php echo e(route('users.force-destroy', $user->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('تحذير! سيتم حذف المستخدم نهائيًا ولا يمكن استرجاعه. هل أنت متأكد؟');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-outline-danger btn-sm table-action-btn" title="Delete Permanently"><i class="fa-solid fa-trash-can"></i></button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center">
                                <div class="py-4">
                                    <i class="fa-solid fa-trash-can fa-2x mb-2"></i>
                                    <p class="mb-0">No deleted users found.</p>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Footer -->
        <div class="custom-table-footer mt-3">

            <div class="custom-table-info">
                Showing
                <?php echo e($users->firstItem() ?? 0); ?>

                to
                <?php echo e($users->lastItem() ?? 0); ?>

                of
                <?php echo e($users->total()); ?>

                deleted users
            </div>

            <nav><?php echo e($users->links()); ?></nav>

        </div>

    </div>

</section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('javascript'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Projects.Dashboard.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Project\Projects\resources\views/Projects/Dashboard/User/trash.blade.php ENDPATH**/ ?>