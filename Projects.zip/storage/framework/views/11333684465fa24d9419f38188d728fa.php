<!doctype html>
<?php echo $__env->make('Projects.Sass.dir', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo $__env->yieldContent('title'); ?></title>

    <?php echo $__env->make('Projects.Sass.css', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <!-- Main + direction stylesheet -->
      <link rel="stylesheet" href="<?php echo e(asset('Projects/Dashboard/css/style.css')); ?>">
    <?php if(in_array(app()->getLocale(), ['en', 'tr'], true)): ?>
        <!-- Main + direction stylesheet LTR -->
        <link id="directionCss" rel="stylesheet" href="<?php echo e(asset('Projects/Dashboard/css/style-ltr.css')); ?>">
    <?php elseif(app()->getLocale() == 'ar'): ?>
        <!-- Main + direction stylesheet RTL -->
        <link id="directionCss" rel="stylesheet" href="<?php echo e(asset('Projects/Dashboard/css/style-rtl.css')); ?>">
    <?php endif; ?>
    <?php echo $__env->yieldContent('css'); ?>
</head>
<body>

    <div class="app-shell">

        <?php echo $__env->make('Projects.Dashboard.include.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="sidebar-overlay" id="sidebarOverlay"></div>

        <div class="app-content" id="appContent">
            
            <?php echo $__env->make('Projects.Dashboard.include.topbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <main class="main-content container-fluid">
                <?php echo $__env->yieldContent('content'); ?>
            </main>

            <?php echo $__env->make('Projects.Dashboard.include.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>

    <?php echo $__env->make('Projects.Sass.javascript', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <script src="<?php echo e(asset('Projects/Dashboard/js/javascript.js')); ?>"></script>
    <?php echo $__env->yieldContent('javascript'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Project\Projects\resources\views/Projects/Dashboard/layout/app.blade.php ENDPATH**/ ?>