

<?php $__env->startSection('title', isset($user) ? 'Edit User' : 'Create User'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="page-heading d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3">

    <div>
        <h1><?php echo e(isset($user) ? 'Edit User' : 'Create User'); ?></h1>
        <p><?php echo e(isset($user) ? 'Update user information below.' : 'Enter the user information below.'); ?></p>
    </div>

    <nav aria-label="breadcrumb">
        <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item">
                <a href="<?php echo e(route('users.index')); ?>">Users</a>
            </li>

            <li class="breadcrumb-item active">
                <?php echo e(isset($user) ? 'Edit' : 'Create'); ?>

            </li>
        </ol>
    </nav>

</div>


<section class="dashboard-card mb-4">

    <div class="card-header-custom flex-wrap gap-3">

        <div>
            <h5><?php echo e(isset($user) ? 'Edit User' : 'Create New User'); ?></h5>

            <small>
                <?php echo e(isset($user) ? 'Update the user information below.' : 'Enter the user information below.'); ?>

            </small>
        </div>


        <button type="submit" form="userForm" class="btn btn-primary btn-sm">
            <i class="fa-solid fa-floppy-disk me-1"></i>
            <?php echo e(isset($user) ? 'Update User' : 'Save User'); ?>

        </button>

    </div>


    <div class="p-3 p-md-4">

        <form id="userForm" action="<?php echo e(isset($user) ? route('users.update', $user->id) : route('users.store')); ?>" method="POST" autocomplete="off">
            <?php echo csrf_field(); ?>
            <?php if(isset($user)): ?>
                <?php echo method_field('PUT'); ?>
            <?php endif; ?>

            <div class="row g-3">
                
                <div class="col-12 col-md-6 col-xl-3">
                    <label for="name" class="form-label form-label-sm">Name<span class="text-danger">*</span></label>
                    <div class="input-group input-group-sm">
                        <span class="input-group-text"><i class="fa-regular fa-user"></i></span>
                        <input type="text" class="form-control form-control-sm" id="name" name="name" value="<?php echo e(old('name', $user->name ?? '')); ?>" placeholder="Enter name" required>
                    </div>
                </div>


                
                <div class="col-12 col-md-6 col-xl-3">
                    <label for="surname" class="form-label form-label-sm">Surname<span class="text-danger">*</span></label>

                    <div class="input-group input-group-sm">
                        <span class="input-group-text"><i class="fa-regular fa-user"></i></span>
                        <input type="text" class="form-control form-control-sm" id="surname" name="surname" value="<?php echo e(old('surname', $user->surname ?? '')); ?>" placeholder="Enter surname" required>
                    </div>
                </div>


                
                <div class="col-12 col-md-6 col-xl-3">
                    <label for="username" class="form-label form-label-sm">Username<span class="text-danger">*</span></label>
                    <div class="input-group input-group-sm">
                        <span class="input-group-text"><i class="fa-solid fa-at"></i></span>
                        <input type="text" class="form-control form-control-sm" id="username" name="username" value="<?php echo e(old('username', $user->username ?? '')); ?>" placeholder="Enter username" required>
                    </div>
                </div>

                
                <div class="col-12 col-md-6 col-xl-3">
                    <label for="email" class="form-label form-label-sm">Email<span class="text-danger">*</span></label>
                    <div class="input-group input-group-sm">
                        <span class="input-group-text"><i class="fa-regular fa-envelope"></i></span>
                        <input type="email" class="form-control form-control-sm" id="email" name="email" value="<?php echo e(old('email', $user->email ?? '')); ?>" placeholder="name@example.com" required>
                    </div>
                </div>


                
                <div class="col-12 col-md-6">
                    <label for="password" class="form-label form-label-sm">Password
                        <?php if(!isset($user)): ?><span class="text-danger">*</span><?php endif; ?>
                    </label>
                    <div class="input-group input-group-sm">
                        <span class="input-group-text"><i class="fa-solid fa-lock"></i></span>
                        <input type="password" class="form-control form-control-sm" id="password" name="password" placeholder="<?php echo e(isset($user) ? 'Leave empty to keep current password' : 'Enter password'); ?>" <?php echo e(!isset($user) ? 'required' : ''); ?>>
                    </div>
                </div>


                
                <div class="col-12 col-md-6">
                    <label for="password_confirmation" class="form-label form-label-sm">Confirm Password
                        <?php if(!isset($user)): ?><span class="text-danger">*</span><?php endif; ?>
                    </label>
                    <div class="input-group input-group-sm">
                        <span class="input-group-text"><i class="fa-solid fa-lock"></i></span>
                        <input type="password" class="form-control form-control-sm" id="password_confirmation" name="password_confirmation" placeholder="Confirm password" <?php echo e(!isset($user) ? 'required' : ''); ?>>
                    </div>
                </div>


                
                <div class="col-12 col-md-6">
                    <label for="status" class="form-label form-label-sm">Status</label>
                    <select class="form-select form-select-sm" id="status" name="status">
                        <option value="1"<?php echo e(old('status', $user->status ?? 1) == 1 ? 'selected' : ''); ?>>Active</option>
                        <option value="0"<?php echo e(old('status', $user->status ?? 1) == 0 ? 'selected' : ''); ?>>Inactive</option>
                    </select>
                </div>

            </div>


            
            <div class="form-actions mt-4">
                <a href="<?php echo e(route('users.index')); ?>" class="btn btn-light btn-sm"><i class="fa-solid fa-arrow-left me-1"></i>Back</a>
                <button type="reset" class="btn btn-light btn-sm"><i class="fa-solid fa-rotate-left me-1"></i>Reset</button>
                <button type="submit" class="btn btn-primary btn-sm"><i class="fa-solid fa-check me-1"></i><?php echo e(isset($user) ? 'Update User' : 'Save User'); ?></button>
            </div>

        </form>

    </div>

</section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('javascript'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Projects.Dashboard.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Project\Projects\resources\views/Projects/Dashboard/User/form.blade.php ENDPATH**/ ?>