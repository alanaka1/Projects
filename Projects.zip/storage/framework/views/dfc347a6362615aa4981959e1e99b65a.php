<footer class="dashboard-footer">
    <span>© 2026 AdminPro</span>
    <span>Built with Bootstrap 5.3.8</span>
</footer><?php /**PATH C:\xampp\htdocs\Project\Projects\resources\views/Projects/Dashboard/include/footer.blade.php ENDPATH**/ ?>