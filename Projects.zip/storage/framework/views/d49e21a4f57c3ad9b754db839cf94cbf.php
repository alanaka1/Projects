
 
<?php $__env->startSection('title', 'Professional Bootstrap Dashboard'); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>

<div class="page-heading d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3">
    <div>
        <h1>Dashboard</h1>
        <p>Welcome back. Here is what is happening today.</p>
    </div>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Dashboard</li>
        </ol>
    </nav>
</div>

<section class="dashboard-card mb-4">
    <div class="card-header-custom flex-wrap gap-3">
        <div class="justify-content-end">
            <h5>Recent Orders</h5>
            <small>Manage latest transactions</small>
        </div>
        <div class="justify-content-end">
            <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus me-1"></i>Add User</a>
            <a href="<?php echo e(route('users.trash')); ?>" class="btn btn-outline-danger btn-sm"><i class="fa-solid fa-trash-can me-1"></i>Trash</a>
        </div>
        
    </div>

    <div class="custom-datatable p-3">
        <!-- Controls -->
        <div class="custom-table-toolbar mb-3">
            <div class="custom-table-length">
                <label for="ordersLength">Show</label>
                <select id="ordersLength" class="form-select form-select-sm">
                    <?php echo $__env->make('Projects.Dashboard.include.ordersLength', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </select>
                <span>entries</span>
            </div>
            <div class="custom-table-search">
                <div class="input-group input-group-sm">
                    <span class="input-group-text">
                        <i class="fa-solid fa-magnifying-glass"></i>
                    </span>
                    <input type="search" id="ordersSearch" class="form-control" placeholder="Search orders...">
                </div>
            </div>
        </div>
        
        <!-- Table -->
        <div class="table-responsive">
            <table id="ordersTable" class="table align-middle table-hover w-100 custom-table">
                <thead>
                    <tr>
                        <th class="sortable" data-column="0">ID <i class="fa-solid fa-sort sort-icon"></i></th>
                        <th class="sortable" data-column="1">Name <i class="fa-solid fa-sort sort-icon"></i></th>
                        <th class="sortable" data-column="2">Surname <i class="fa-solid fa-sort sort-icon"></i></th>
                        <th class="sortable" data-column="3">Username <i class="fa-solid fa-sort sort-icon"></i></th>
                        <th class="sortable" data-column="4">Email <i class="fa-solid fa-sort sort-icon"></i></th>
                        <th class="sortable" data-column="5">Status <i class="fa-solid fa-sort sort-icon"></i></th>
                        <th class="sortable" data-column="6">Action <i class="fa-solid fa-sort sort-icon"></i></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    <tr>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->surname); ?></td>
                        <td><?php echo e($user->username); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td>
                            <form action="<?php echo e(route('users.status', $user->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>

                                <button type="submit" class="btn <?php echo e($user->status == 1 ? 'btn-outline-danger' : 'btn-outline-info'); ?> btn-sm table-action-btn" title="<?php echo e($user->status == 1 ? 'تعطيل' : 'تفعيل'); ?>">
                                    <i class="fa-solid <?php echo e($user->status == 1 ? 'fa-thumbs-down' : 'fa-thumbs-up'); ?>"></i>
                                </button>
                            </form>
                        </td>
                        <td>
                            <div class="d-flex align-items-center gap-1 flex-nowrap">
                                <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-outline-success btn-sm table-action-btn" title="Edit"><i class="fa-solid fa-pen-to-square"></i></a>
                                <a href="<?php echo e(route('users.show', $user->id)); ?>" class="btn btn-outline-secondary btn-sm table-action-btn" title="Show"><i class="fa-solid fa-eye"></i></a>
                                <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="POST" onsubmit="return confirm('هل أنت متأكد من حذف هذا المستخدم؟');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-outline-danger btn-sm table-action-btn" title="Delete"><i class="fa-solid fa-trash-can"></i></button>
                                </form>
                                
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </tbody>
            </table>
        </div>

        <!-- Footer -->
        <div class="custom-table-footer mt-3">
            <div id="ordersInfo" class="custom-table-info"></div>
            <nav><ul id="ordersPagination" class="pagination pagination-sm mb-0"></ul></nav>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Projects.Dashboard.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Project\Projects\resources\views/Projects/Dashboard/User/index.blade.php ENDPATH**/ ?>