<?php

namespace App\Http\Controllers\Projects\Auth;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    /**
     * Display a listing of the resource User. --- اعرض قائمة بمورد المستخدم.
     */
    public function index()
    {
        $users = User::orderBy('id', 'DESC')->get();
        return view('Projects.Auth.User.index', compact('users'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('Projects.Auth.User.form');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try{

            $data = [
                'name'      => $request->name,
                'surname'   => $request->surname,
                'username'  => $request->username,
                'email'     => $request->email,
                'password'  => $request->password,
                'status'    => $request->status ?? 1,
            ];

            if (!empty($data['password'])) {
                $data['password'] = Hash::make($data['password']);
            } else {
                unset($data['password']);
            }

            User::create($data);
            
                return redirect(route('users.index'))->with(['success' => 'تمت إضافة المستخدم بنجاح']);
            }catch(\Exception $ex){
                return redirect(route('users.index'))->with(['error' => 'حدثت مشكلة أثناء إضافة المستخدم']);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show($user)
    {
        $user = User::find($user);

        if (!$user) {
            return redirect(route('users.index'))->with(['error' => 'المستخدم المطلوب غير موجود']);
        }

        return view('Projects.Auth.User.show',compact('user'));
        }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($user)
    {
        $user = User::find($user);

        if (!$user) {
            return redirect(route('users.index'))->with(['error' => 'المستخدم المطلوب غير موجود']);
        }

        return view('Projects.Auth.User.form', compact('user'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $user)
    {
        try{
            $user = User::find($user);
            if(!$user){
                return redirect(route('users.index'))->with(['error' => 'المستخدم المطلوب غير موجود']);
            }
            $data = $request->only(['name', 'surname', 'username', 'email', 'password', 'status']);

            if (!empty($data['password'])) {
                $data['password'] = Hash::make($data['password']);
            } else {
                unset($data['password']);
            }

            $user->update($data);
    
            return redirect(route('users.index'))->with(['success' => 'تم تعديل المستخدم بنجاح']);
        }catch(\Exception $ex){
            return redirect(route('users.index'))->with(['error' => 'حدثت مشكلة أثناء تعديل المستخدم']);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($user)
    {
        try {

            $user = User::find($user);
            if (!$user) {
                return redirect(route('users.index'))->with(['error' => 'المستخدم المطلوب غير موجود']);
            }
            
            $user->delete();
            return redirect(route('users.index'))->with(['success' => 'تم نقل المستخدم إلى سلة المحذوفات بنجاح']);
        } catch (\Exception $ex) {
            return redirect(route('users.index'))->with(['error' => 'حدثت مشكلة أثناء حذف المستخدم']);
        }
    }

    /**
     * Display deleted users. --- عرض المستخدمين المحذوفين مبدئيًا.
    */
    public function trash()
    {
        $users = User::onlyTrashed()->orderBy('deleted_at', 'DESC')->paginate(10);
        return view('Projects.Auth.User.trash', compact('users'));
    }

    /**
     * Display force Restore users. --- استرجاع المستخدم من سلة المحذوفات.
    */
    
    public function restore($user)
    {
        try {

            $user = User::onlyTrashed()->find($user);

            if (!$user) {
                return redirect(route('users.trash'))->with(['error' => 'المستخدم المطلوب غير موجود في سلة المحذوفات']);
            }

            $user->restore();

            return redirect(route('users.trash'))->with(['success' => 'تم استرجاع المستخدم بنجاح']);
        } catch (\Exception $ex) {
            return redirect(route('users.trash'))->with(['error' => 'حدثت مشكلة أثناء استرجاع المستخدم']);
        }
    }

    /**
     * Display force Destroy users. --- حذف المستخدم نهائيًا من سلة المحذوفات.
    */

    public function forceDestroy($user)
    {
        try {

            $user = User::onlyTrashed()->find($user);

            if (!$user) {
                return redirect(route('users.trash'))->with(['error' => 'المستخدم المطلوب غير موجود في سلة المحذوفات']);
            }

            $user->forceDelete();

            return redirect(route('users.trash'))->with(['success' => 'تم حذف المستخدم نهائيًا']);
        } catch (\Exception $ex) {
            return redirect(route('users.trash'))->with(['error' => 'تم حذف المستخدم نهائيًا']);
        }
    }

    /**
     * تفعيل أو تعطيل التصنيف. = Change Category Status
     */
    public function updateStatus(User $user)
    {
        try {

            $user->update(['status' => $user->status == 1 ? 0 : 1,]);

            return redirect(route('users.index'))->with(['success' => $user->status == 1 ? 'تم تفعيل المستخدم بنجاح' : 'تم تعطيل المستخدم بنجاح']);
        } catch (\Exception $ex) {
            return redirect(route('users.index'))->with(['error' => 'حدثت مشكلة أثناء تغيير حالة المستخدم']);
        }
    }
}
